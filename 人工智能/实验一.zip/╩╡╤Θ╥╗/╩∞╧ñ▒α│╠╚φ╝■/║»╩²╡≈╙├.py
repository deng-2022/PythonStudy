def print_alg():
    A = float(input("请输入A的值: "))
    B = float(input("请输入B的值: "))

    result = 3 * A + 2 * B
    print("3A+2B的结果为:", result)


if __name__ == '__main__':
    print_alg()
