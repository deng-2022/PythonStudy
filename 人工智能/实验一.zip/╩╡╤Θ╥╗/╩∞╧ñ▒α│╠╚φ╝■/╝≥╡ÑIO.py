# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

def print_alg():
    x = float(input("请输入x的值: "))
    result = 2 * x + 5
    print("2*x+5的结果为:", result)


if __name__ == '__main__':
    print_alg()
